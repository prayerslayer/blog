library('concaveman')
library('ggplot2')
library('rnaturalearth')
library('rnaturalearthhires')
library('sp')
library('SimilarityMeasures')
library('parallel')
library('pracma')
library('pbmcapply')

WEB_MERC <-
  sp::CRS(
    '+proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=0.0 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +wktext  +no_defs'
  )
EQ_EARTH <-
  sp::CRS('+proj=eqearth +lon_0=0 +datum=WGS84 +units=m +no_defs')

max_frac <- 10
countries <-
  list('mauritania', 'thailand', 'poland', 'panama')
result <- matrix(0, ncol = 5, nrow = 0)
colnames(result) <- c('i', 'jitter', 'country', 'measure', 'value')
jitter_seeds <-
  c(164, 286, 349, 356, 668) # obtained from random.org


P.countries <- list()
for (country_name in countries) {
  print(country_name)
  country_poly <-
    sp::spTransform(rnaturalearth::ne_countries(scale = 'large', country = country_name),
                    EQ_EARTH)

  area_km2 <-
    country_poly@polygons[[1]]@area
  # roughly 1 point per 100 km^2
  # means smaller countries will have less points
  # would maybe be nicer to scale all countries to unit area and sample a fixed number of points into them
  # but since each country is made of multiple polygons, this is a bit annoying
  N <- ceiling(area_km2 * 1e-08)
  set.seed(1) # call this directly before every `spsample` for reproducability
  P <- sp::spsample(country_poly, N, 'random')@coords
  diameter <- max(dist(P))
  bottom_left <- apply(P, 2, min)
  # concavity = 1 -> take every detail on the boundary but avoid digging too far and getting weird shapes. many points.
  # concavity = 2 -> default, apparently good compromise of detail and amount of points.
  # since former makes frechet distance calculation computationally infeasible on my machine, compromise with 1.5
  O <- concaveman::concaveman(P, concavity = 1.5)


  frechet.K <- rep(-1, max_frac)
  for (i in 2:max_frac) {
    print(i)
    k <- ceiling(diameter / i)
    splits <- columncells::determine_splits(P)
    K.cells <- columncells::place_k_cells(P, k, k, splits = splits)
    K <- columncells::union_cells(K.cells, k, k, splits = splits)
    # Compute this here already as it is the most expensive operation
    if (length(K) == 1) {
      frechet.K[i] <- SimilarityMeasures::Frechet(O, K[[1]])
    }
  }

  P.countries[[country_name]] <- list(
    P = P,
    diameter = diameter,
    bottom_left = bottom_left,
    O = O,
    frechetK = frechet.K
  )
}


params <-
  expand.grid(countries,
              2:max_frac,
              jitter_seeds,
              list('frechet', 'numcells'))
params <- sample(nrow(params)) %>% purrr::map(function(i) {
  return(list(params = params[i, ],
              data = P.countries[[params[i, 1][[1]]]]))
})
#pbmcapply::pbmc
result <- parallel::mclapply(params, function(param) {
  P <- param$data$P
  O <- param$data$O
  diameter <- param$data$diameter
  bottom_left <- param$data$bottom_left
  i <- param$params$Var2
  k <- ceiling(diameter / i)
  j <- param$params$Var3
  measure <- param$params$Var4[[1]]
  country <- param$params$Var1[[1]]
  splits <- columncells::determine_splits(P)
  K.cells <- columncells::place_k_cells(P, k, k, splits = splits)
  K <- columncells::union_cells(K.cells, k, k, splits = splits)

  # plot(sf::st_multipolygon(append(
  #   K %>% purrr::map(function(x) {return(sf::st_polygon(list(x)))}),
  #   list(sf::st_polygon(list(O)))
  # )))

  set.seed(j)
  jitter <- runif(2) * k / 2
  origin <- bottom_left - jitter
  G.cells <- columncells::place_grid(P, k, origin = origin)
  G <- columncells::union_cells(G.cells, k, k, splits = 1:2)

  value.K <- NA
  value.G <- NA

  if (measure == 'numcells') {
    value.K <- nrow(K.cells)
    value.G <- nrow(G.cells)
  } else if (measure == 'hausdorff') {
    if (length(K) == 1 && length(G) == 1) {
      value.K <- pracma::hausdorff_dist(K[[1]], O)
      value.G <- pracma::hausdorff_dist(G[[1]], O)
    }
  } else if (measure == 'frechet') {
    if (length(K) == 1 && length(G) == 1) {
      value.K <- param$data$frechetK[i]
      value.G <-
        SimilarityMeasures::Frechet(G[[1]], O)

      # may return -1 for some reason
      if (value.K < 0 || value.G < 0) {
        # reset
        value.K <- NA
        value.G <- NA
      }
    }
  }

  print(paste(i, j, k, country, measure, value.K, value.G))

  return(list(
    i = i,
    j = j,
    country = country,
    measure = measure,
    valueK = value.K,
    valueG = value.G
  ))
}, mc.cores = (parallel::detectCores() - 1), mc.silent = F)
#, mc.cores = (parallel::detectCores() - 1), mc.silent = F

means <- do.call(rbind, result)
means <- as.data.frame(means)
means$i <- as.numeric(means$i)
means$j <- as.numeric(means$j)
means$valueG <- as.numeric(means$valueG)
means$valueK <- as.numeric(means$valueK)
means$country <- unlist(means$country)
means$measure <- unlist(means$measure)

means <- means %>% dplyr::filter(!is.na(valueK) &
                                   !is.na(valueG) &
                                   valueK > 0 & valueG > 0)

# compute harmonic mean across jitter values (harmonic because ratio values)
means <- means %>%
  dplyr::mutate(value = valueK / valueG) %>%
  dplyr::group_by(country, i, measure) %>%
  dplyr::summarise(mean_value = 1 / mean(1 / value)) %>%
  data.frame()


ggplot2::ggplot(means) + ggplot2::geom_line(ggplot2::aes(x = i,
                                                         color=measure,
                                                         y = mean_value),
                                            #shape = country),
                                            size = 1) +
  ggplot2::geom_hline(yintercept = 1) +
  ggplot2::scale_color_discrete(name = 'seed') +
  ggplot2::scale_y_continuous(
    name = 'Harmonic mean of relative value',
    limits = c(0.5, 1.2),
    breaks = c(0.5, 0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.2)
  ) +
  ggplot2::scale_x_continuous(name = 'Cell side length (D/i)') +
  ggplot2::theme_bw() +
  ggplot2::theme(
    #legend.text = element_text(size = 10),
    legend.position = 'none',
    #legend.direction = 'horizontal',
    axis.title = element_text(size = 14),
    strip.text.x = element_text(size = 14),
    strip.text.y = element_text(size = 14)
  ) +
  ggplot2::facet_grid(rows = vars(measure), cols = vars(country))


View(means)

# Checking specific parameter combinations visually if you want

country_name <-
  'poland'
i <- 10
j <- 1
jitter_seeds[j]
country_poly <-
  sp::spTransform(rnaturalearth::ne_countries(scale = 'large', country = country_name),
                  EQ_EARTH)
area_km2 <-
  country_poly@polygons[[1]]@area
N <-
  ceiling(area_km2 * 1e-08)
set.seed(1) # call this directly before every `spsample` for reproducability
P <-
  sp::spsample(country_poly, N, 'random')@coords
diameter <-
  max(dist(P))
k <-
  ceiling(diameter / i)

splits <- columncells::determine_splits(P)
K <-
  columncells::place_k_cells(P, k, k, splits = splits)
K.u <-
  columncells::union_cells(K, k, k, splits = splits)
columncells::vis(P, columncells::rects_to_polys(K), k)
#columncells::vis(P, columncells::polys_to_polys(K.u), k)

bottom_left <-
  apply(P, 2, min)
set.seed(jitter_seeds[j])
jitter <-
  runif(2) * k / 2
G <-
  columncells::place_grid(P, k, bottom_left - jitter)
columncells::vis(P, columncells::rects_to_polys(G), k)
G.u <- columncells::union_cells(G, k, k, splits = 1:2)
#columncells::vis(P, columncells::polys_to_polys(G.u), k)

