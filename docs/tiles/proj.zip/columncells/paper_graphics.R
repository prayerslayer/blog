library('concaveman')
library('ggplot2')
library('rnaturalearth')
library('rnaturalearthhires')
library('sp')
library('SimilarityMeasures')
library('robCompositions')

util_to_ntiles <- function(population,
                           sample = c(),
                           ntiles = 6) {
  percentiles <-
    quantile(population, probs = 0:ntiles * 1 / ntiles) %>% unname()

  # return sample as ntiles of population, if provided
  if (length(sample) > 0) {
    return(sample %>% purrr::map(function(m) {
      return(dplyr::last(which(percentiles[1:ntiles] <= m)))
    }) %>% unlist() %>% unname())
  }

  # return percentile cuts otherwise
  return(percentiles)
}


data(gemas)

WEB_MERC <-
  sp::CRS(
    '+proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=0.0 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +wktext  +no_defs'
  )
EQ_EARTH <-
  sp::CRS('+proj=eqearth +lon_0=0 +datum=WGS84 +units=m +no_defs')
WGS84 <- sp::CRS('+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs')
gemas

variable <- 'Na'
gemas.spatial <-
  sp::spTransform(
    sp::SpatialPointsDataFrame(gemas[, c('longitude', 'latitude')], data.frame(gemas[, variable]), proj4string = WGS84),
    WEB_MERC
  )
P <- as.matrix(gemas.spatial@coords)
colnames(P) <- c("x", "y")

k <- ceiling(max(dist(P))/10)
K <- columncells::place_k_cells(P, k, k, columncells::determine_splits(P))
G <- columncells::place_grid(P, k, origin=apply(P, 2, min) - c(k,k)/2)
columncells::vis(P, columncells::rects_to_polys(K), 1.5*k)
columncells::vis(P, columncells::rects_to_polys(G), 1.5*k)
X <- K
# "Al"        "Ba"        "Ca"        "Cr"        "Fe"        "K"         "Mg"
# "Mn"        "Na"

cell_medians <- columncells::separate(P, X) %>% purrr::map(function(idxs) {return(median(gemas[idxs, variable]))}) %>%unlist()

ggplot2::ggplot(as.data.frame(cbind(X, cell_medians))) + ggplot2::geom_rect(
  mapping = ggplot2::aes(xmin = xmin,
                         xmax=xmax,
                         ymin=ymin,
                         ymax=ymax,
                         fill = cell_medians),
  size=0.25,
  color='darkgray'
) + ggplot2::coord_fixed() + ggplot2::scale_fill_gradient() +
  ggplot2::theme_bw() +
  ggplot2::theme(
    plot.title = ggplot2::element_text(hjust = 0.5, size=16, family = 'Monaco'),
    axis.title = ggplot2::element_blank(),
    axis.text = ggplot2::element_blank(),
    axis.ticks = ggplot2::element_blank(),
    panel.grid = ggplot2::element_blank(),
    legend.position='none'
  )

# voronoi diagram for comparison
ggplot2::ggplot(as.data.frame(cbind(P, gemas[,variable]))) +
  ggvoronoi::geom_voronoi(aes(x=x,y=y,fill=V3)) +
  ggplot2::coord_fixed() +
  ggplot2::scale_fill_gradient() +
  ggplot2::theme_bw() +
  ggplot2::theme(
    plot.title = ggplot2::element_text(hjust = 0.5, size=16, family = 'Monaco'),
    axis.title = ggplot2::element_blank(),
    axis.text = ggplot2::element_blank(),
    axis.ticks = ggplot2::element_blank(),
    panel.grid = ggplot2::element_blank(),
    legend.position='none'
  )

# alpha shape
ah <- alphahull::ashape(P,alpha=100000)
plot(alphahull::ashape(P,alpha=100000), wpoints=F, wlines='none')

# bubble map
ggplot2::ggplot(as.data.frame(cbind(P, gemas[,variable]))) +
  ggplot2::geom_point(mapping=ggplot2::aes(x=x,y=y,colour=V3)) +
  ggplot2::coord_fixed() +
  ggplot2::scale_size_binned() +
  ggplot2::theme_bw() +
  ggplot2::theme(
    plot.title = ggplot2::element_text(hjust = 0.5, size=16, family = 'Monaco'),
    axis.title = ggplot2::element_blank(),
    axis.text = ggplot2::element_blank(),
    axis.ticks = ggplot2::element_blank(),
    panel.grid = ggplot2::element_blank(),
    legend.position='none'
  )
