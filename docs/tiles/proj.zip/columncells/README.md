# columncells

Grids for points, without the empty space.

## Example

```R
library('columncells')

# P is a two-column matrix with X and Y coordinates of points
# Use, e.g., uniform 2D point cloud
P <- matrix(runif(200), ncol=2)
colnames(P) <- c('x', 'y')

# Cell side length
k <- 0.1

# Get arrangement with square cells of size k
S <- columncells::place_k_cells(P, k)

# Show result
columncells::vis(P, columncells::rects_to_polys(S), k)

# Compare to a possible regular grid
G <- columncells::place_grid(P, k)
columncells::vis(P, columncells::rects_to_polys(G), k)

# Separate point cloud according to cell arrangement
columncells::separate(P, S)
```

### Countries Example

Same as above, but use this to get `P`:

```R
library('rnaturalearth')
library('rnaturalearthhires')
library('sp')

WEB_MERC <-
  sp::CRS('+proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=0.0 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +wktext  +no_defs')
  
country_name <- 'united kingdom'
country_poly <- sp::spTransform(rnaturalearth::ne_countries(scale = 'large', country = country_name), WEB_MERC)

area <- country_poly@polygons[[1]]@area # area in web mercator coordinate system, mind you
N <- ceiling(area * 1e-08)
set.seed(1) # call this directly before every `spsample` for reproducability
P <- round(sp::spsample(country_poly, N, 'random')@coords)
k <- round(max(dist(P))/10)
S <- columncells::place_k_cells(P, k)
G <- columncells::place_grid(P,k)
columncells::vis(P, columncells::rects_to_polys(S), k)
columncells::vis(P, columncells::polys_to_polys(columncells::union_cells(S,k)), k)
columncells::vis(P, columncells::polys_to_polys(columncells::union_cells(G,k)), k)
columncells::vis(P, columncells::rects_to_polys(G), k)
```

### Bivariate Gaussians Example

```R
library('MASS')

mu1 <- c(-2, 2)
covar1 <- matrix(c(1, 0.75,
                  0.75, 1), ncol=2)
P.gaussian1 <- MASS::mvrnorm(500, mu1, covar1)

mu2 <- c(2,2)
covar2 <- matrix(c(1, 0.25,
                   0.25, 1), ncol=2)
P.gaussian2 <- MASS::mvrnorm(500, mu2, covar2)

P <- rbind(P.gaussian1, P.gaussian2)
```

## How to

### ... use interactively like a developer

1. Checkout this project
2. Open in RStudio
3. `devtools::load_all()`
4. Fool around (see, e.g., examples section)

### ...install

TBA

## Citation

TBA
