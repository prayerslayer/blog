#' Convert arrangement for `vis` call
#' @export
#' @param S the arrangement
rects_to_polys <- function(S) {
  U <- matrix(ncol = 3,
              data = 0,
              nrow = 0)
  for (i in 1:nrow(S)) {
    U <- rbind(U, cbind(i, rect_to_poly(S[i, ])))
  }
  colnames(U) <- c('group', 'x', 'y')
  return(U)
}

plot_polys <- function(P,Q) {
  plot(
    sf::st_multipolygon(list(
      sf::st_polygon(list(P)),
      sf::st_polygon(list(Q))
    ))
  )
}

#' Convert a single cell to a `sf` polygon.
#' @export
#' @param rect the cell
#' @return a `sf` polygon
rect_to_poly <- function(rect) {
  x1 <- rect[1]
  x2 <- rect[2]
  y1 <- rect[3]
  y2 <- rect[4]

  return(matrix(
    ncol = 2,
    byrow = T,
    data = c(x1, y1,
             x2, y1,
             x2, y2,
             x1, y2,
             x1, y1)
  ))
}

#' Convert cells in arrangement to a list of `sf` polygons for easy `plot`ting.
#' @export
#' @param S the arrangement
#' @return a list of `sf` polygons
rects_to_polys_list <- function(S){
  U <- list()
  for (i in 1:nrow(S)){
    U <- append(U, list(sf::st_polygon(list(rect_to_poly(S[i,])))))
  }
  return(U)
}


polys_to_polys <- function(S) {
  # S is output from union_cells
  U <- matrix(ncol = 3,
              data = 0,
              nrow = 0)
  i <- 1
  for (poly in S) {
    U <- rbind(U, cbind(i, poly))
    i <- i + 1
  }
  colnames(U) <- c('group', 'x', 'y')
  return(U)
}


#' Plot a point set, optionally also with cells.
#'
#' @param P Point set. Should be data frame or matrix with two columns 'x' and 'y'.
#' @param S Cells. Output of place_k_cells or place_grid.
#' @export
vis <- function(P, S = NA, margin = 0) {
  x1 <- min(P[, 1])
  x2 <- max(P[, 1])
  y1 <- min(P[, 2])
  y2 <- max(P[, 2])
  ylim <- c(y1 - margin, y2 + margin)
  xlim <- c(x1 - margin, x2 + margin)

  p <- ggplot2::ggplot(as.data.frame(P)) +
    ggplot2::theme_bw() +
    ggplot2::geom_point(ggplot2::aes(x = x,
                                     y = y), size = 0.25) +
    ggplot2::coord_fixed(
      expand=F,
      ylim=ylim,
      xlim=xlim
    ) +
    ggplot2::theme(
      axis.title = ggplot2::element_blank(),
      axis.text = ggplot2::element_blank(),
      axis.ticks = ggplot2::element_blank(),
      panel.grid = ggplot2::element_blank()
    )

  if (!all(is.na(S))) {
    p + ggplot2::geom_polygon(
      data = as.data.frame(S),
      mapping = ggplot2::aes(x = x,
                             group = group,
                             y = y),
      colour = 'red',
      size = 0.25,
      alpha = 0.125,
      fill = 'red'
    )
  } else {
    p
  }
}

#' Finds groups of consecutive numbers in a vector that have the same difference.
#'
#' @param config The vector of numbers.
#' @param k The difference
#' @param eps Epsilon, for comparison of reals. Defaults to 1e-02.
#' @return A list of groups, which are index vectors.
find_consecutive_diff <- function(config, k, eps = 1e-02) {
  i <- 1
  n <- length(config)
  r <- list()
  current <- c(1)
  if (n == 1) {
    return(list(c(1)))
  }
  while (i < n) {
    if (abs(dplyr::nth(config, i) - dplyr::nth(config, i + 1)) - k < eps) {
      current <- c(current, i + 1)
    } else {
      if (length(current) > 0) {
        r <- append(r, list(current))
        current <- c(i + 1)
      }
    }
    i <- i + 1
  }
  if (length(current) > 0) {
    r <- append(r, list(current))
  }
  return(r)
}

#' The actual 1D computation of the technique
#' @param data the points in a vector
#' @param k the interval
#' @param snap the snapping distance. if subsequent intervals are closer than that apart, they are changed to be contiguous for visual continuity.
#' @param eps a parameter because i don't know how to properly compare floats in R
#' @return a list of lists of intervals `c(start,end)`
place_intervals <- function(data,
                         k,
                         snap = k / 1000,
                         eps = 1e-05) {
  data <- sort(data)
  config <- c()
  n <- length(data)
  i <- 1
  while (i <= n) {
    # find start point of interval
    start_at <- data[i]
    last_point_covered <-
      tail(data[data < start_at + k], 1)
    trailing_space <- start_at + k - last_point_covered
    start_at <- start_at - trailing_space / 2

    # if there's an interval with enough trailing space, close to its predecessor, we snap to that
    if (length(config) > 0) {
      prev_square_end <- dplyr::last(config) + k
      start_at <- max(prev_square_end, start_at)
      if (start_at - prev_square_end <= snap) {
        start_at <- prev_square_end
      }
    }

    config <- c(config, start_at)
    last_covered.idx <- dplyr::last(which(data < start_at + k))
    i <- last_covered.idx + 1
  }

  # Centering loop
  repeat {
    groups <- find_consecutive_diff(config, k, eps)
    if (length(groups) == 0) {
      break
    }
    compensated <- F
    for (i in 1:length(groups)) {
      g <- groups[[i]]
      start <- config[dplyr::first(g)]
      end <- config[dplyr::last(g)] + k
      end.prev <- -Inf
      if (i > 1) {
        g.prev <- groups[[i - 1]]
        end.prev <- config[dplyr::last(g.prev)] + k
      }
      points_in_group <- data[data >= start & data < end]
      first_point_covered <-
        head(points_in_group, 1)
      last_point_covered <-
        tail(points_in_group, 1)
      actual_padding.start <- (first_point_covered - start)
      actual_padding.end <- (end - last_point_covered)
      best_padding <-
        1 / 2 * (actual_padding.start + actual_padding.end)
      gap_available <- max(start - end.prev, 0)
      compensation <- 0
      compensation_necessary <- best_padding - actual_padding.start
      compensation_possible <- actual_padding.end - eps
      if (gap_available > eps && compensation_necessary > eps) {
        # imbalanced padding and there is room to improve
        compensation <- min(gap_available, compensation_necessary)
        if (compensation_necessary <= snap &&
            !is.infinite(gap_available)) {
          compensation <- min(gap_available, compensation_possible)
        }
        compensated <- T
      }

      config[g] <- config[g] - compensation
    }
    if (!compensated) {
      break
    }
  }
  return(config)
}

edge_to_poly <- function(edge, left, width) {
  top <- edge[1]
  bot <- edge[2]
  M <- matrix(
    ncol = 2,
    byrow = T,
    data = c(left, top,
             left + width, top,
             left + width, bot,
             left, bot,
             left, top)
  )
  return(M)
}

do_polys_intersect <- function(P, Q) {
  P.star <- sf::st_polygon(list(P))
  Q.star <- sf::st_polygon(list(Q))

  interiors_intersect <-
    any(sf::st_relate(P.star, Q.star, 'T********', sparse = F))
  line_intersection_on_boundary <-
    any(sf::st_relate(P.star, Q.star, '****1****', sparse = F))

  intersection <- interiors_intersect || line_intersection_on_boundary
  return(intersection)
}

merge_polys <- function(P, Q) {
  PQ <- sf::st_union(sf::st_polygon(list(P)), sf::st_polygon(list(Q)))
  PQ.coords <- sf::st_coordinates(PQ)[,1:2]
  if (!all(PQ.coords[nrow(PQ.coords),] == PQ.coords[1,])) {
    # this polygon is not closed, so maybe we obtained a hole through the merge
    # assuming this, we return the first poly (exterior)
    return(PQ[[1]])
  }
  return(PQ.coords)
}

get_from_update_list <- function(l, k) {
  # update list: a list of immutable complex objects. if one was updated, it holds an
  # index to the updated version
  while (length(l[[k]]) == 1 && is.atomic(l[[k]])) {
    k <- l[[k]]
  }
  return(l[[k]])
}

#' Rotate a set of points by given angle.
#' @param P the points (n x 2 matrix)
#' @param angle the angle in radians
#' @return rotated P
rotate <- function(P, angle) {
  Rot <- matrix(ncol=2, c(
    cos(angle),
    sin(angle),
    -sin(angle),
    cos(angle)
  ))
  P.rot <- P %*% Rot
  colnames(P.rot) <- c('x', 'y')
  return(P.rot)
}

#' Convert a cell arrangement into its corner points, in no particular order.
#' @param S the arrangement (n x 4 matrix)
#' @return the corner points (2n x 2 matrix)
arrangement_to_corners <- function(S) {
  return(rbind(S[,c(1,3)], S[,c(2,4)]))
}

#' Transform corner points of an arrangement into an arrangement
#' @param U the points (nx2 matrix)
#' @return the arrangement ((n/2)x4 matrix)
corners_to_arrangement <- function(U) {
  return(cbind(
    U[1:(nrow(U)/2),],
    U[(nrow(U)/2+1):nrow(U),]
  )[,c(1,3,2,4)])
}

#' Rotates cells in an arrangement by the given angle.
#' @param S the arrangement, output by `place_k_cells` or `place_grid`
#' @param angle the angle in radians. is assumed to be multiples of pi/2 because the data structure of S expects axis-parallel lines
#' @return same arrangement, rotated.
rotate_cells <- function(S, angle) {
  U <- corners_to_arrangement(rotate(arrangement_to_corners(S), angle))
  colnames(U) <- c('xmin', 'xmax', 'ymin', 'ymax')
  return(U)
}

#' Computes the cell arrangement S of P as a union of neighbouring rectangles.
#'
#' @param S the arrangement
#' @param k width of cell
#' @param l height of cell, defaults to width
#' @param splits vector with dimension processing order (1:2, 2:1 or NULL, in which case `determine_splits` is used)
#' @return A list of orthogonal polygons that are the union of the arrangement
union_cells <- function(S, k, l = k, splits=NULL) {
  # The idea is to do a plane sweep along the first split dimension
  # in each column we find consecutive vertical edges and check if they touch
  # any of the unions (sweep line status). if so, they are merged. if not, they
  # form a new union.
  all_polys <- list()
  result <- sets::set()

  if (is.null(splits)) {
    splits <- determine_splits(arrangement_to_corners(S))
  }

  if (!all(splits==1:2)) {
    # TODO the rounding shouldn't actually be necessary but otherwise it doesn't
    # union nicely with 2:1 splits, and I need this now.
    S <- round(rotate_cells(S, pi/2))
  }

  # in goes xmin, xmax, ymin, ymax
  # make it xmin, ymin, xmax, ymax
  S <- S[,c(1,3,2,4)]
  S <- S[statnet.common::order(S),]

  columns <- S[, 1]
  colgroups <- find_consecutive_diff(columns, k)

  for (colgroup in colgroups) {
    sweep_status <-
      rbst::bst() # key = row height, value = index into all_polys
    cols <- unique(columns[colgroup])

    for (col in cols) {
      rows <- S[S[, 1] == col, 2]

      keys_to_process <-
        sets::as.set(rbst::keys(sweep_status))
      processed_keys <- c()

      for (group in find_consecutive_diff(rows, l)) {
        top <- rows[max(group)] + l
        bot <- rows[min(group)]

        edge <- c(top, bot)


        possible_intersections <- list()
        if (!rbst::is_empty(sweep_status)) {
          low <- rbst::floor_of(sweep_status, bot)
          high <- rbst::ceiling_of(sweep_status, top)

          if (is.null(low) && is.null(high)) {
            # we're intersecting all existing keys
            possible_intersections <- rbst::keys(sweep_status)
          }else if (!is.null(low) && !is.null(high)) {
            possible_intersections <-
              rbst::keys_between(sweep_status,
                                 low, high)
          } else if (is.null(low)) {
            possible_intersections <-
              rbst::keys_between(sweep_status, rbst::min_key(sweep_status), high)
          } else if (is.null(high)) {
            possible_intersections <-
              rbst::keys_between(sweep_status, low, rbst::max_key(sweep_status))
          }
        }

        actual_intersections <-
          rep(F, length(possible_intersections))

        if (length(possible_intersections) > 0) {
          for (u in 1:length(possible_intersections)) {
            t <- possible_intersections[[u]]
            poly_id <- rbst::retrieve(sweep_status, t)
            poly <- get_from_update_list(all_polys, poly_id)
            this.poly <- edge_to_poly(edge, col, k)

            if (do_polys_intersect(poly, this.poly)) {
              actual_intersections[u] <- T
              processed_keys <- c(processed_keys, t)
            }
          }
        }

        if (any(actual_intersections)) {
          # possibly multiple intersections
          # get all polygons that are intersecting
          # since they are intersecting a common edge, they are now all 1 polygon
          idxs <- c(which(actual_intersections))

          # find mapping polygon -> idx
          mapping <- hash::hash()

          for (idx in idxs) {
            t <- possible_intersections[[idx]]
            poly_id <- as.character(rbst::retrieve(sweep_status, t))
            if (!hash::has.key(poly_id, mapping)) {
              mapping[[poly_id]] <- c(idx)
            } else {
              mapping[[poly_id]] <- c(mapping[[poly_id]], idx)
            }
          }

          new_poly <- edge_to_poly(edge, col, k)
          new_poly_id <- length(all_polys) + 1
          for (poly_id_str in hash::keys(mapping)) {
            intersections <- mapping[[poly_id_str]]
            poly_id <- as.numeric(poly_id_str)
            poly <- get_from_update_list(all_polys, poly_id)

            for (idx in intersections) {
              t <- possible_intersections[[idx]]
              sweep_status <- rbst::delete(sweep_status, t)
            }

            new_poly <- merge_polys(new_poly, poly)
            all_polys[[poly_id]] <- new_poly_id
          }

          all_polys <- append(all_polys, list(new_poly))
          t.prime <- top
          sweep_status <-
            rbst::insert(sweep_status, t.prime, new_poly_id)
        } else {
          # no intersections - this is a new thing
          all_polys <-
            append(all_polys, list(edge_to_poly(edge, col, k)))
          sweep_status <-
            rbst::insert(sweep_status, top, length(all_polys))
        }
      }

      not_intersected <-
        keys_to_process - sets::as.set(processed_keys)
      for (key in not_intersected) {
        poly_id <- rbst::retrieve(sweep_status, key)
        result <- result | sets::as.set(c(poly_id))
        sweep_status <- rbst::delete(sweep_status, key)
      }
    }

    result <-
      result |
      sets::as.set(rbst::keys(sweep_status) %>% purrr::map(function(t) {
        return(rbst::retrieve(sweep_status, t))
      }) %>% unlist())

  }
  result_list <- list()
  for (poly_id in result) {
    result_list <-
      append(result_list, list(get_from_update_list(all_polys, poly_id)))
  }
  if (!all(splits==1:2)) {
    result_list <- result_list %>% purrr::map(function(poly) {return(rotate(poly, -pi/2))})
  }
  return(result_list)
}

#' Split a point set as they are distributed in the cell arrangement.
#'
#' @export
#' @param P The point set. DF or matrix with columns 'x' and 'y'
#' @param S The cell arrangement. Output of place_grid or place_k_cells.
#' @return List of vectors with point indices. Vector in list i has row indexes from P for points that are in cell i.
separate <- function(P, S) {
  return(apply(S, 1, function(r) {
    xmin <- r[1]
    xmax <- r[2]
    ymin <- r[3]
    ymax <- r[4]

    if (r[2] <= r[1]) {
      xmin <- r[2]
      xmax <- r[1]
    }

    P.contained <- which(P[, 1] >= xmin &
                           P[, 1] < xmax &
                           P[, 2] >= ymin &
                           P[, 2] < ymax)
    return(P.contained)
  }))
}

#' Counts how many points are not in a cell, which is not allowed.
num_points_not_covered <- function(P, S) {
  points_in_cells <-
    separate(P, S) %>% purrr::map(function(p) {
      return(length(p))
    }) %>% purrr::reduce(.f = sum, .init = 0)
  return(nrow(P) - points_in_cells)
}

#' Automatically determines dimension processing order.
#' @export
#' @param P the points
#' @return a vector 1:2 or 2:1
determine_splits <- function(P) {
  extent <- apply(P, 2, function(col){
    minmax <- range(col)
    return(abs(minmax[2]-minmax[1]))
  })
  splits <- order(extent, decreasing = T)
  return(splits)
}

#' Compute arrangement for a point set.
#'
#' @export
#' @param P The point set. DF or matrix with columns 'x' and 'y'
#' @param k The cell width.
#' @param l The cell height. Defaults to width.
#' @param splits A vector giving the order of dimensions. Should be 1:2 (X-Y) or 2:1 (Y-X).
#' @return An arrangement of cells. Matrix with 4 columns c('xmin', 'xmax', 'ymin', 'ymax') that describe the cell.
place_k_cells <- function(P, k, l = k, splits = 1:2) {
  tiles <- matrix(0, nrow = 0, ncol = 4)

  # If no splits, we pick it automatically based on the extent of coordinates
  if (is.null(splits)) {
    splits <- determine_splits(P)
  }

  # If the splits are not 1:2, we rotate the points and pretend they are 1:2
  P.in <- P
  if (!all(splits==1:2)) {
    P <- rotate(P, pi/2)
  }

  columns <- place_intervals(P[, 1], k)

  for (col in columns) {
    strip <-
      matrix(P[P[, 1] >= col &
                 P[, 1] < col + k,], ncol = 2)
    rows <- place_intervals(strip[, 2], l)

    for (r in rows) {
      tiles <- rbind(tiles, c(col, col + k, r, r + l))
    }
  }

  if (!all(splits==1:2)) {
    tiles <- rotate_cells(tiles, -1/2*pi)
  }

  colnames(tiles) <- c('xmin', 'xmax', 'ymin', 'ymax')

  #uncovered <- num_points_not_covered(P.in, tiles)
  #if (uncovered > 0) {
  #  warning(paste(uncovered, 'points not covered!'))
  #}
  return(tiles)
}


#' Compute grid arrangement for a point set.
#'
#' @export
#' @param P The point set. DF or matrix with columns 'x' and 'y'
#' @param k The cell side length in X and Y direction.
#' @param origin the left bottom origin to use for the grid. defaults to bottom left point of P's bounding box.
#' @return An arrangement of cells. Matrix with 4 columns c('xmin', 'xmax', 'ymin', 'ymax') that describe the cell.
place_grid <- function(P, k, origin=NULL) {
  fake_var <- 1:nrow(P)
  P.reg <-
    sp::SpatialPointsDataFrame(P, data.frame(fake_var))

  if (is.null(origin)) {
    origin <- apply(P, 2, min)
  }
  right_top <- apply(P, 2, max)

  num_cells <- ceiling( (right_top - origin) / k )

  grid <-
    sp::SpatialGrid(sp::GridTopology(
      origin,
      cellsize = c(k, k),
      cells.dim = num_cells
    ))
  G <- raster::aggregate(P.reg, grid, median)
  S <- t(apply(sp::coordinates(G), 1, function(r) {
    xmin <- r[1]
    ymin <- r[2]
    xmax <- xmin + k
    ymax <- ymin + k
    return(c(xmin, xmax, ymin, ymax))
  }))

  S.final <- matrix(0, nrow = 0, ncol = 4)
  for (i in 1:nrow(S)) {
    xmin <- S[i, 1]
    xmax <- S[i, 2]
    ymin <- S[i, 3]
    ymax <- S[i, 4]
    points <- matrix(P[P[, 1] >= xmin &
                         P[, 1] < xmax &
                         P[, 2] >= ymin &
                         P[, 2] < ymax, ], ncol = 2)
    if (nrow(points) > 0) {
      S.final <- rbind(S.final, S[i,])
    }
    colnames(S.final) <- c('xmin', 'xmax', 'ymin', 'ymax')
  }
  return(S.final)
}
