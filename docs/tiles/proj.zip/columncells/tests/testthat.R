library(testthat)
library(columncells)

test_check("columncells")
